package org.nomfamille.exo4;

public class LibExterne {


    /* -------------- PAS DE TESTS -------------*/


    public static void main(String[] args) {

    }
}
