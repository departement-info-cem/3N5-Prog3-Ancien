package org.nomfamille.exo1;

public class Imperatif {


   /* -------------- MODIFIEZ UNIQUEMENT LE CODE, PAS LES TESTS -------------*/


    public static String rectangle(int hauteur, int largeur){
        return null;
    }

    public static Integer premiersEntiers(int max){
        return null;
    }


}
