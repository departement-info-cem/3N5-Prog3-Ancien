package org.nomfamille.exo3;

public class CopieFichier {


    /* -------------- PAS DE TESTS -------------*/


    public static void main(String[] args) {

    }

}
