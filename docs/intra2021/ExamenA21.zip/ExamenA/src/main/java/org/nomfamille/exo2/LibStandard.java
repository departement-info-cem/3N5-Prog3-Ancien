package org.nomfamille.exo2;

import java.util.List;

public class LibStandard {


    /* -------------- MODIFIEZ UNIQUEMENT LE CODE, PAS LES TESTS -------------*/


    public static List<Integer> nFoisN(int max) {
        return null;
    }

    public static List<Integer> triCroissant(List<Integer> source) {
        return null;
    }

}
