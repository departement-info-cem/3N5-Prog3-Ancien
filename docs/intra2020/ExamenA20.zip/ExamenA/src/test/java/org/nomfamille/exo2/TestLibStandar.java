package org.nomfamille.exo2;

import org.junit.Assert;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class TestLibStandar {

	/**
	 * VOUS DEVEZ MODIFIER LA LIGNE SUIVANTE
	 */

	@Test(timeout = 1000)
	public void testnFoidNNegatif(){
		List<Integer> result = LibStandar.nFoisN(-99);
		Assert.assertEquals(null,result);

	}

	@Test(timeout = 1000)
	public void testnFoidN1(){
		List<Integer> result = LibStandar.nFoisN(1);
		Assert.assertEquals(Arrays.asList(1),result);

	}

	@Test(timeout = 1000)
	public void testnFoidN4(){
		List<Integer> result = LibStandar.nFoisN(4);
		Assert.assertEquals(Arrays.asList(1,2,2,3,3,3,4,4,4,4),result);

	}

	@Test(timeout = 1000)
	public void testnFoidN10(){
		List<Integer> result = LibStandar.nFoisN(10);
		Assert.assertEquals(Arrays.asList(
				1,
				2,2,
				3,3,3,
				4,4,4,4,
				5,5,5,5,5,
				6,6,6,6,6,6,
				7,7,7,7,7,7,7,
				8,8,8,8,8,8,8,8,
				9,9,9,9,9,9,9,9,9,
				10,10,10,10,10,10,10,10,10,10),result);

	}

	@Test(timeout = 1000)
	public void testTriDecroissant(){
		List<Integer> nonTriee = new ArrayList<>();
		nonTriee.addAll(Arrays.asList(1,2,3));
		System.out.println("Liste de départ est  " + nonTriee);
		List<Integer> result = LibStandar.triDecroissant(nonTriee);
		System.out.println("résultat de la méthode  " + result);
		Assert.assertEquals(Arrays.asList(3,2,1) , result);
	}

	@Test(timeout = 1000)
	public void testTriDecroissant2(){
		List<Integer> nonTriee = new ArrayList<>();
		nonTriee.addAll(Arrays.asList(23,10,15,-9,-900,50,0,0));
		System.out.println("Liste de départ est  " + nonTriee);
		List<Integer> result = LibStandar.triDecroissant(nonTriee);
		System.out.println("résultat de la méthode  " + result);
		Assert.assertEquals(Arrays.asList(50,23,15,10,0,0,-9,-900) , result);
	}

}



