package org.nomfamille.exo2;

import java.util.List;
import java.util.Map;

public class LibStandar {

    public static List<Integer> nFoisN(int max) {
        return null;
    }

    public static List<Integer> triDecroissant(List<Integer> source) {
        return null;
    }

}
