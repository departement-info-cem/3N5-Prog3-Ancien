package org.nomfamille.exo3;

public class ParamsFichiers {

    public static void main(String[] args) {
        // Mettre votre code ici. Pour cet exercice, pas de tests de correction
    }

}
