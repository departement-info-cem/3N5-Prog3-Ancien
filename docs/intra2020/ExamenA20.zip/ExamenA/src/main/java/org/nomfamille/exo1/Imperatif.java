package org.nomfamille.exo1;

import java.util.*;

public class Imperatif {


   /* -------------- MODIFIEZ UNIQUEMENT LE CODE, PAS LES TESTS -------------*/


    public static String aT(int hauteur){
        throw new UnsupportedOperationException(); // Votre code remplace cette ligne
    }

    public static Integer bPremiersEntiers(int max){
        throw new UnsupportedOperationException(); // Votre code remplace cette ligne
    }

    public static String[] cCopie(int longueur, String depart){
        throw new UnsupportedOperationException(); // Votre code remplace cette ligne
    }


}
